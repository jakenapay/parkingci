<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">    
        <li id="dashboardSideNav">  
          <a href="<?php echo base_url('Treasury') ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard ..</span>
          </a>   
        </li>     
        <li id="profileSideTree"><a href="<?php echo base_url('treasury/reports/') ?>"><i class="fa fa-user-circle"></i> <span>Reports</span></a></li>      

           
        <li><a href="<?php echo base_url('auth/logout') ?>"><i class="fa fa-power-off"></i> <span>Logout</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
    
  </aside>